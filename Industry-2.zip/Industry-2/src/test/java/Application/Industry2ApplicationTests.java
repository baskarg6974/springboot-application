package Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Industry2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
